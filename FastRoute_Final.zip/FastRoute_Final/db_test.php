<?php
require_once __DIR__ . '/config/requireconfig.php';

if (isset($db)) {
    echo "DB Connesso correttamente!<br>";
    $stmt = $db->query("SELECT 'OK' AS risultato");
    $row = $stmt->fetch();
    echo "Test query: " . $row->risultato;
} else {
    echo "ERRORE: \$db non è definito.<br>";
    echo "Verifica config/databaseConfig.php e che MySQL sia attivo.";
}
?>