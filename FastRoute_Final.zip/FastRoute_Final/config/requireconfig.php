<?php
// Avvia la sessione se non è attiva
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// Carica le configurazioni
$appConfig = require __DIR__ . '/appconfig.php';
$dbConfig = require __DIR__ . '/databaseConfig.php';

// Definisce le costanti di percorso
define('BASE_URL', $appConfig['baseUrl']);
define('LAYOUTS_PATH', $appConfig['layouts']);
define('PAGES_PATH', $appConfig['pages']);

// Include le dipendenze principali
require_once __DIR__ . '/../app/core/DatabaseConn.php';
require_once __DIR__ . '/../app/functions/funzioni_db.php';

// Inizializza la connessione al database
try {
    $db = DatabaseConn::getDB($dbConfig);
} catch (PDOException $e) {
    $_SESSION['messaggio_errore'] = "Connessione al database fallita: " . $e->getMessage();
    header("Location: " . BASE_URL . "/app/views/pages/messagepage.php");
    exit;
}
?>