<?php
return [
    'layouts' => __DIR__ . '/../app/views/layouts/',
    'pages' => __DIR__ . '/../app/views/pages/',
    'baseUrl' => '/FastRoute_Final',
];