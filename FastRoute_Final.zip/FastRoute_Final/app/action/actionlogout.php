<?php
require_once __DIR__ . '/../../config/requireconfig.php';
$_SESSION = array();
session_destroy();
header("Location: " . BASE_URL . "/app/views/pages/login.php");
exit;