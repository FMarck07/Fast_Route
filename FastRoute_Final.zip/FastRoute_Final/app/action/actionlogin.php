<?php
require_once __DIR__ . '/../../config/requireconfig.php';
if (!isset($db)) {
    die("ERRORE: \$db non è definito. Verifica requireconfig.php e la connessione.");
}
if (isset($_POST['btn_login'])) {
    $user = verificaLogin($db, $_POST['email'], $_POST['password']);
    if ($user) {
        $_SESSION['user_id'] = $user->ID_Personale;
        $_SESSION['tema'] = $user->Tema_Grafico;
        $_SESSION['primo_accesso'] = $user->Primo_Accesso;
        $next = ($user->Primo_Accesso) ? "profilo.php" : "dashboard.php";
        header("Location: " . BASE_URL . "/app/views/pages/" . $next);
        exit;
    } else {
        $_SESSION['login_error'] = "Credenziali errate.";
        header("Location: " . BASE_URL . "/app/views/pages/login.php");
        exit;
    }
} else {
    header("Location: " . BASE_URL . "/app/views/pages/login.php");
    exit;
}