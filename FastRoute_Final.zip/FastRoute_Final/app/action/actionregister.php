<?php
require_once __DIR__ . '/../../config/requireconfig.php';
// Eventuale implementazione futura per registrazione
header("Location: " . BASE_URL . "/app/views/pages/index.php");
exit;