<?php
// LETTURA
function getPlichi($db) {
    return $db->query('SELECT Plico.*, Cliente.Nome, Cliente.Cognome FROM Plico JOIN Cliente ON Plico.ID_Mittente = Cliente.ID_Cliente ORDER BY DataOra_Accettazione DESC');
}
function getClienti($db) { return $db->query('SELECT * FROM Cliente'); }
function getSedi($db) { return $db->query('SELECT * FROM Sede'); }
function verificaLogin($db, $email, $password) {
    $stmt = $db->prepare('SELECT * FROM Personale WHERE Email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    return ($user && password_verify($password, $user->Password)) ? $user : false;
}
function getStatisticheRitiro($db, $giorni) {
    $stmt = $db->prepare("SELECT COUNT(*) as Totale FROM Plico WHERE Stato_Plico = 'Ritirato' AND DataOra_Ritiro >= DATE_SUB(NOW(), INTERVAL ? DAY)");
    $stmt->execute([(int)$giorni]);
    return $stmt->fetch();
}

// SCRITTURA
function inserisciRichiestaInfo($db, $n, $e, $m) {
    $db->prepare('INSERT INTO Richiesta_Info (Nome, Email, Messaggio) VALUES (?,?,?)')->execute([$n,$e,$m]);
}
function inserisciCliente($db, $n, $c, $i, $t, $e) {
    $db->prepare('INSERT INTO Cliente (Nome, Cognome, Indirizzo, Telefono, Email) VALUES (?,?,?,?,?)')->execute([$n,$c,$i,$t,$e]);
}
function inserisciPlico($db, $idm, $nd, $cd, $id, $sp, $sa) {
    $db->prepare('INSERT INTO Plico (ID_Mittente, Nome_Destinatario, Cognome_Destinatario, Indirizzo_Destinatario, ID_Sede_Partenza, ID_Sede_Arrivo) VALUES (?,?,?,?,?,?)')->execute([$idm,$nd,$cd,$id,$sp,$sa]);
}

// AGGIORNAMENTO STATI
function spedisciPlico($db, $id) {
    $db->prepare("UPDATE Plico SET Stato_Plico = 'In Transito', DataOra_Spedizione = NOW() WHERE Codice_Plico = ? AND Stato_Plico = 'In Partenza'")->execute([$id]);
}
function ritiraPlico($db, $id) {
    $db->beginTransaction();
    try {
        $stmt = $db->prepare("SELECT Stato_Plico, ID_Mittente FROM Plico WHERE Codice_Plico = ? FOR UPDATE");
        $stmt->execute([$id]);
        $plico = $stmt->fetch();

        if (!$plico || $plico->Stato_Plico === 'Ritirato') {
            $db->rollBack();
            return false;
        }

        $db->prepare("UPDATE Plico SET Stato_Plico = 'Ritirato', DataOra_Ritiro = NOW() WHERE Codice_Plico = ?")->execute([$id]);
        $db->prepare("UPDATE Cliente SET Punti_Fedelta = Punti_Fedelta + 1 WHERE ID_Cliente = ?")->execute([$plico->ID_Mittente]);

        $db->commit();
        return true;
    } catch (Exception $e) {
        $db->rollBack();
        return false;
    }
}

// PROFILO
function aggiornaPassword($db, $id, $pwd) {
    $hash = password_hash($pwd, PASSWORD_DEFAULT);
    $db->prepare('UPDATE Personale SET Password = ?, Primo_Accesso = FALSE WHERE ID_Personale = ?')->execute([$hash, $id]);
}
function aggiornaTema($db, $id, $tema) {
    $db->prepare('UPDATE Personale SET Tema_Grafico = ? WHERE ID_Personale = ?')->execute([$tema, $id]);
}
function getRichiesteInfo($db) {
    return $db->query('SELECT * FROM Richiesta_Info ORDER BY Data_Invio DESC');
}