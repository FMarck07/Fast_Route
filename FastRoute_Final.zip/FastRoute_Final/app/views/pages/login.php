<?php
require_once __DIR__ . '/../../../config/requireconfig.php';

if (isset($_SESSION['user_id'])) {
    header("Location: " . BASE_URL . "/app/views/pages/dashboard.php");
    exit;
}

require_once LAYOUTS_PATH . 'header.php';
?>
    <h1>Login Personale</h1>
<?php
if (isset($_SESSION['login_error'])) {
    echo "<p class='msg-err'>" . htmlspecialchars($_SESSION['login_error']) . "</p>";
    unset($_SESSION['login_error']);
}
?>
    <form method="POST" action="<?= BASE_URL ?>/app/action/actionlogin.php">
        Email: <input type="email" name="email" required>
        Password: <input type="password" name="password" required>
        <button type="submit" name="btn_login">Entra</button>
    </form>
<?php require_once LAYOUTS_PATH . 'footer.php'; ?>