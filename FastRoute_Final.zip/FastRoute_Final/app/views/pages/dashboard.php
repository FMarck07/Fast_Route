<?php
require_once __DIR__ . '/../../../config/requireconfig.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: " . BASE_URL . "/app/views/pages/login.php");
    exit;
}
if (isset($_SESSION['primo_accesso']) && $_SESSION['primo_accesso']) {
    header("Location: " . BASE_URL . "/app/views/pages/profilo.php");
    exit;
}

require_once LAYOUTS_PATH . 'header.php';
?>

    <h1>Dashboard Gestionale FastRoute</h1>

    <h2>Tutte le Spedizioni Registrate</h2>
    <table>
        <tr>
            <th>Codice</th>
            <th>Mittente</th>
            <th>Stato</th>
            <th>Data Accettazione</th>
            <th>Data Ritiro</th>
        </tr>
        <?php
        $plichi = getPlichi($db);
        foreach($plichi as $p):
            ?>
            <tr>
                <td><?= $p->Codice_Plico ?></td>
                <td><?= htmlspecialchars($p->Nome) ?> <?= htmlspecialchars($p->Cognome) ?></td>
                <td><strong><?= $p->Stato_Plico ?></strong></td>
                <td><?= $p->DataOra_Accettazione ?></td>
                <td><?= $p->DataOra_Ritiro ?? '<span class="ritiro-null">In attesa...</span>' ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <hr>

    <h2>Statistiche Ritiri</h2>
    <form method="GET" class="stats-form">
        <span>Visualizza plichi ritirati negli ultimi</span>
        <input type="number" name="n" value="<?= $_GET['n'] ?? 7 ?>" class="stats-input">
        <span>giorni</span>
        <button type="submit">Calcola</button>
    </form>

<?php
if (isset($_GET['n'])) {
    $stat = getStatisticheRitiro($db, $_GET['n']);
    echo "<p class='stats-result'>Totale plichi ritirati nel periodo: <strong>" . $stat->Totale . "</strong></p>";
}
?>

    <hr>

    <h2>Richieste Informazioni (Messaggi dal Sito)</h2>
    <table class="msg-info-table">
        <tr>
            <th>Data Invio</th>
            <th>Nome Visitatore</th>
            <th>E-mail</th>
            <th>Messaggio</th>
        </tr>
        <?php
        $richieste = getRichiesteInfo($db);
        foreach($richieste as $r):
            ?>
            <tr>
                <td><?= $r->Data_Invio ?></td>
                <td><?= htmlspecialchars($r->Nome) ?></td>
                <td><?= htmlspecialchars($r->Email) ?></td>
                <td><?= nl2br(htmlspecialchars($r->Messaggio)) ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

<?php require_once LAYOUTS_PATH . 'footer.php'; ?>