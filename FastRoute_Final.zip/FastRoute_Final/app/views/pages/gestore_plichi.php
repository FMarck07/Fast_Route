<?php
require_once __DIR__ . '/../../../config/requireconfig.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: " . BASE_URL . "/app/views/pages/login.php");
    exit;
}
if (isset($_SESSION['primo_accesso']) && $_SESSION['primo_accesso']) {
    header("Location: " . BASE_URL . "/app/views/pages/profilo.php");
    exit;
}

$msg = '';

if (isset($_POST['btn_accetta'])) {
    inserisciPlico($db, $_POST['mid'], $_POST['nd'], $_POST['cd'], $_POST['id'], $_POST['sp'], $_POST['sa']);
    $msg = "Plico Accettato!";
}
if (isset($_POST['btn_spedisci'])) {
    spedisciPlico($db, $_POST['cod']);
    $msg = "Plico in Transito!";
}
if (isset($_POST['btn_ritira'])) {
    $result = ritiraPlico($db, $_POST['cod']);
    $msg = $result ? "Plico Ritirato!" : "Operazione non riuscita (plico già ritirato o inesistente).";
}

require_once LAYOUTS_PATH . 'header.php';
?>
    <h1>Gestione Operativa Plichi</h1>
<?php if ($msg) echo "<p class='msg-ok'>$msg</p>"; ?>

    <h3>1. Accettazione (Nuovo Plico)</h3>
    <form method="POST" action="">
        Mittente: <select name="mid"><?php foreach(getClienti($db) as $c) echo "<option value='$c->ID_Cliente'>$c->Nome $c->Cognome</option>"; ?></select>
        Sede Partenza: <select name="sp"><?php foreach(getSedi($db) as $s) echo "<option value='$s->ID_Sede'>$s->Nome</option>"; ?></select>
        Sede Arrivo: <select name="sa"><?php foreach(getSedi($db) as $s) echo "<option value='$s->ID_Sede'>$s->Nome</option>"; ?></select>
        Destinatario (Nome/Cognome/Indirizzo):
        <input type="text" name="nd" placeholder="Nome" required>
        <input type="text" name="cd" placeholder="Cognome" required>
        <input type="text" name="id" placeholder="Indirizzo" required>
        <button type="submit" name="btn_accetta">Registra Consegna</button>
    </form>

    <h3>2. Spedizione / 3. Ritiro</h3>
    <form method="POST" action="">
        Codice Plico: <input type="number" name="cod" required>
        <button type="submit" name="btn_spedisci">Segna come Spedito</button>
        <button type="submit" name="btn_ritira" style="background:green">Conferma Ritiro</button>
    </form>

<?php require_once LAYOUTS_PATH . 'footer.php'; ?>