<?php
require_once __DIR__ . '/../../../config/requireconfig.php';
$messaggio = isset($_SESSION['messaggio_errore']) ? $_SESSION['messaggio_errore'] : "Messaggio.";
unset($_SESSION['messaggio_errore']);
$pagina_precedente = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : BASE_URL . '/app/views/pages/index.php';
?>
<!doctype html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Messaggio - FastRoute</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/public/css/mystyle.css">
</head>
<body>
<div class="error-container">
    <h1 class="error-title">Attenzione</h1>
    <h2><?= htmlspecialchars($messaggio) ?></h2><br><br>
    <a href="<?= htmlspecialchars($pagina_precedente) ?>" class="btn">Torna Indietro</a>
    <a href="<?= BASE_URL ?>/app/views/pages/index.php" class="btn btn-black">Vai alla Home</a>
</div>
</body>
</html>