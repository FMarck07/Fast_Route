<?php
require_once __DIR__ . '/../../../config/requireconfig.php';
require_once __DIR__ . '/../../../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$email_loggata = isset($_SESSION['user_id']) ? ($_SESSION['email_personale'] ?? '') : '';
$msg_info = '';

if (isset($_POST['btn_richiesta'])) {
    $nome = $_POST['nome'];
    $messaggio = $_POST['messaggio'];
    $email_mittente = ($email_loggata != '') ? $email_loggata : $_POST['email'];

    try {
        inserisciRichiestaInfo($db, $nome, $email_mittente, $messaggio);

        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = "smtp.gmail.com";
        $mail->SMTPAuth = true;
        $mail->Username = "francesco.marchetto@iisviolamarchesini.edu.it";
        $mail->Password = "otst chvk tcjq ajji";
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom("francesco.marchetto@iisviolamarchesini.edu.it", "Sistema FastRoute");
        $mail->addAddress("marchettofrancesco14@gmail.com");
        $mail->addReplyTo($email_mittente, $nome);
        $mail->Subject = "Nuova richiesta info da: " . $nome;
        $mail->Body = "Hai ricevuto un nuovo messaggio.\n\nNome: $nome\nEmail: $email_mittente\n\nMessaggio:\n$messaggio";
        $mail->CharSet = "UTF-8";
        $mail->Encoding = "base64";

        $mail->send();
        $msg_info = "<span class='msg-ok'>Richiesta inviata e inoltrata via mail con successo!</span>";
    } catch (Exception $e) {
        $msg_info = "<span class='msg-error'>Richiesta salvata, ma errore invio mail: {$mail->ErrorInfo}</span>";
    } catch (PDOException $e) {
        $_SESSION['messaggio_errore'] = "Errore invio: " . $e->getMessage();
        header("Location: " . BASE_URL . "/app/views/pages/messagepage.php");
        exit;
    }
}

require_once LAYOUTS_PATH . 'header.php';
?>

    <h1>Benvenuti in FastRoute</h1>
    <h2>Richiesta Informazioni</h2>
<?php if($msg_info) echo $msg_info; ?>

    <form action="<?= BASE_URL ?>/app/views/pages/index.php" method="POST">
        Nome: <input type="text" name="nome" required><br><br>
        E-mail: <input type="email" name="email" value="<?= htmlspecialchars($email_loggata) ?>" <?= ($email_loggata != '') ? 'readonly' : 'required' ?>><br><br>
        Messaggio:<br>
        <textarea name="messaggio" rows="4" required></textarea><br><br>
        <button type="submit" name="btn_richiesta">Invia Richiesta</button>
    </form>

<?php require_once LAYOUTS_PATH . 'footer.php'; ?>