<?php
$tema = $_SESSION['tema'] ?? 'light';
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>FastRoute</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/public/css/mystyle.css">
</head>
<body class="tema-<?= $tema ?>">
<div class="navbar">
    <a href="<?= BASE_URL ?>/app/views/pages/index.php">Home Pubblica</a>
    <?php if(isset($_SESSION['user_id'])): ?>
        <a href="<?= BASE_URL ?>/app/views/pages/dashboard.php">Dashboard</a>
        <a href="<?= BASE_URL ?>/app/views/pages/gestore_plichi.php">Operazioni Plichi</a>
        <a href="<?= BASE_URL ?>/app/views/pages/nuovo_cliente.php">Anagrafica Clienti</a>
        <a href="<?= BASE_URL ?>/app/views/pages/profilo.php">Mio Profilo</a>
        <a href="<?= BASE_URL ?>/app/action/actionlogout.php">Esci</a>
    <?php else: ?>
        <a href="<?= BASE_URL ?>/app/views/pages/login.php">Login Staff</a>
    <?php endif; ?>
</div>