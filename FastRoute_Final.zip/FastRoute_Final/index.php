<?php
require_once __DIR__ . '/config/requireconfig.php';
require LAYOUTS_PATH . 'header.php';
$content = $_GET['content'] ?? 'Benvenuti in FastRoute - Gestione Corriere';
?>
    <h1 class="content"><?= htmlspecialchars($content) ?></h1>
<?php
require LAYOUTS_PATH . 'footer.php';