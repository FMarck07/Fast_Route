<?php
// Semplice script per creare l'admin nel nuovo database
require_once __DIR__ . '/config/requireconfig.php';

$email = 'admin@fastroute.it';
$password = 'Admin123!';   // cambia se vuoi
$hash = password_hash($password, PASSWORD_DEFAULT);

// Elimina eventuale admin esistente (opzionale)
$db->prepare("DELETE FROM Personale WHERE Email = ?")->execute([$email]);

// Inserisce il nuovo admin
$db->prepare("INSERT INTO Personale (Email, Password, Tema_Grafico, Primo_Accesso) VALUES (?, ?, 'light', TRUE)")
    ->execute([$email, $hash]);

echo "Admin creato!<br>Email: $email<br>Password: $password<br>";
echo '<a href="' . BASE_URL . '/app/views/pages/login.php">Vai al login</a>';
?>