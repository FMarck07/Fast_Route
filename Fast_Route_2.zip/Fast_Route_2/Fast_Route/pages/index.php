<?php



use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;



// 1. Inclusioni corrette (usando ../ per uscire dalla cartella pages)
require_once '../configuration/DatabaseConn.php';
$dbconfig = require '../configuration/DBconfiguration.php';
require_once '../function/funzioni_db.php';
require_once '../vendor/autoload.php';

// 2. Connessione al database
$db = DatabaseConn::getDB($dbconfig);

if(is_null($db)){
    exit("Errore del database");
}

// 3. Gestione del form
if (isset($_POST['btn_richiesta'])) {

    try {

        // Salva nel database
        inserisciRichiestaInfo($db, $_POST['nome'], $_POST['email'], $_POST['messaggio']);

        // INOLTRO MAIL CON PHPMAILER
        $mail = new PHPMailer(true);

        $mail->isSMTP();
        $mail->Host = "smtp.gmail.com";
        $mail->SMTPAuth = true;
        $mail->Username = "alessio.poli@iisviolamarchesini.edu.it";
        $mail->Password = "yezr flxn jbho htwx";
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom("alessio.poli@iisviolamarchesini.edu.it");
        $mail->addAddress("enrico.prearo@iisviolamarchesini.edu.it");

        $mail->addReplyTo($_POST['email'], $_POST['nome']);

        // Uso i dati del form per comporre l'oggetto e il testo
        $mail->Subject = "Nuova richiesta info da: " . $_POST['nome'];
        $mail->Body = "Hai ricevuto un nuovo messaggio.\n\nNome: " . $_POST['nome'] . "\nEmail: " . $_POST['email'] . "\n\nMessaggio:\n" . $_POST['messaggio'];
        $mail->CharSet = "UTF-8";
        $mail->Encoding = "base64";

        $mail->send();

        $msg_info = "<span class='msg-ok'>Richiesta inviata e inoltrata via mail con successo!</span>";

    } catch (Exception $e) {
        // Cattura gli errori specifici di PHPMailer
        $msg_info = "<span class='msg-error'>Richiesta salvata, ma errore invio mail: {$mail->ErrorInfo}</span>";
    } catch (PDOException $e) {
        // Cattura gli errori del database
        session_start();
        $_SESSION['messaggio_errore'] = "Errore invio: " . $e->getMessage();
        header("Location: errore.php");
        exit;
    }
}

require_once 'header.php';
?>

    <h1>Benvenuti in FastRoute</h1>
    <h2>Richiesta Informazioni</h2>

<?php if(isset($msg_info)) echo $msg_info; ?>

    <form action="index.php" method="POST">
        Nome: <input type="text" name="nome" required>
        E-mail: <input type="email" name="email" required>
        Messaggio: <textarea name="messaggio" rows="4" required></textarea>
        <button type="submit" name="btn_richiesta">Invia Richiesta</button>
    </form>

<?php require_once 'footer.php'; ?>