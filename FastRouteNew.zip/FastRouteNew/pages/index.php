<?php
// 1. AVVIAMO LA SESSIONE PER CAPIRE CHI È LOGGATO
if(session_status() !== PHP_SESSION_ACTIVE) session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Inclusioni corrette
require_once '../configuration/DatabaseConn.php';
$dbconfig = require '../configuration/DBconfiguration.php';
require_once '../function/funzioni_db.php';
require_once '../vendor/autoload.php';

// Connessione al database
$db = DatabaseConn::getDB($dbconfig);

if(is_null($db)){
    exit("Errore del database");
}

// 2. RECUPERIAMO L'EMAIL DI CHI HA FATTO L'ACCESSO (se esiste)
// Se l'utente non è loggato, questa variabile sarà vuota
$email_loggata = isset($_SESSION['email_personale']) ? $_SESSION['email_personale'] : '';

// Gestione del form
if (isset($_POST['btn_richiesta'])) {

    try {
        // Se l'utente è loggato forziamo la sua email, altrimenti usiamo quella scritta nel form
        $email_mittente = ($email_loggata != '') ? $email_loggata : $_POST['email'];
        $nome_mittente = $_POST['nome'];

        // Salva nel database
        inserisciRichiestaInfo($db, $nome_mittente, $email_mittente, $_POST['messaggio']);

        // INOLTRO MAIL CON PHPMAILER
        $mail = new PHPMailer(true);

        $mail->isSMTP();
        $mail->Host = "smtp.gmail.com";
        $mail->SMTPAuth = true;
        // Questo DEVE rimanere il tuo: è il "motore" autorizzato da Google a spedire
        $mail->Username = "francesco.marchetto@iisviolamarchesini.edu.it";
        $mail->Password = "otst chvk tcjq ajji";
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Il mittente ufficiale per Google (sempre tu)
        $mail->setFrom("francesco.marchetto@iisviolamarchesini.edu.it", "Sistema FastRoute");
        // invia la mail a un admin
        $mail->addAddress("mohamed.guezam@iisviolamarchesini.edu.it");

        // LA MAGIA: Impostiamo la risposta per chi ha fatto l'accesso (o chi ha compilato il form)
        $mail->addReplyTo($email_mittente, $nome_mittente);

        // Uso i dati per comporre l'oggetto e il testo
        $mail->Subject = "Nuova richiesta info da: " . $nome_mittente;
        $mail->Body = "Hai ricevuto un nuovo messaggio.\n\nNome: " . $nome_mittente . "\nEmail: " . $email_mittente . "\n\nMessaggio:\n" . $_POST['messaggio'];
        $mail->CharSet = "UTF-8";
        $mail->Encoding = "base64";

        $mail->send();

        $msg_info = "<span class='msg-ok'>Richiesta inviata e inoltrata via mail con successo!</span>";

    } catch (Exception $e) {
        $msg_info = "<span class='msg-error'>Richiesta salvata, ma errore invio mail: {$mail->ErrorInfo}</span>";
    } catch (PDOException $e) {
        $_SESSION['messaggio_errore'] = "Errore invio: " . $e->getMessage();
        header("Location: errore.php");
        exit;
    }
}

require_once 'header.php';
?>

    <h1>Benvenuti in FastRoute</h1>
    <h2>Richiesta Informazioni</h2>

<?php if(isset($msg_info)) echo $msg_info; ?>

    <form action="index.php" method="POST">
        Nome: <input type="text" name="nome" required><br><br>

        E-mail: <input type="email" name="email" value="<?php echo htmlspecialchars($email_loggata); ?>" <?php echo ($email_loggata != '') ? 'readonly' : 'required'; ?>><br><br>

        Messaggio:<br>
        <textarea name="messaggio" rows="4" required></textarea><br><br>

        <button type="submit" name="btn_richiesta">Invia Richiesta</button>
    </form>

<?php require_once 'footer.php'; ?>