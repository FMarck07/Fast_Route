<?php
require_once '../configuration/DatabaseConn.php';
$dbconfig = require '../configuration/DBconfiguration.php';
$db = DatabaseConn::getDB($dbconfig);
$h = password_hash("Admin123!", PASSWORD_DEFAULT);
$db->prepare("INSERT INTO Personale (Email, Password) VALUES ('admin@fastroute.it', ?)")->execute([$h]);
echo "Utente creato! Email: admin@fastroute.it | Pass: Admin123!";