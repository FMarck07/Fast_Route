<?php
// *** Eseguire questo script UNA SOLA VOLTA per creare l'utente admin.
// *** Dopo l'uso, proteggilo (es. spostalo fuori dalla root) o eliminalo per sicurezza. ***

require_once '../configuration/DatabaseConn.php';
$dbconfig = require '../configuration/DBconfiguration.php';
$db = DatabaseConn::getDB($dbconfig);
$h = password_hash("Admin123!", PASSWORD_DEFAULT);
$db->prepare("INSERT INTO Personale (Email, Password) VALUES ('admin@fastroute.it', ?)")->execute([$h]);
echo "Utente creato! Email: admin@fastroute.it | Pass: Admin123!";