<?php
require_once '../configuration/DatabaseConn.php';
$dbconfig = require '../configuration/DBconfiguration.php';
require_once '../function/funzioni_db.php';
$db = DatabaseConn::getDB($dbconfig);
session_start();
if($_SESSION['primo_accesso']) header("Location: profilo.php");

if(isset($_POST['btn_accetta'])) {
    inserisciPlico($db, $_POST['mid'], $_POST['nd'], $_POST['cd'], $_POST['id'], $_POST['sp'], $_POST['sa']);
    $msg = "Plico Accettato!";
}
if(isset($_POST['btn_spedisci'])) {
    spedisciPlico($db, $_POST['cod']);
    $msg = "Plico in Transito!";
}
if(isset($_POST['btn_ritira'])) {
    ritiraPlico($db, $_POST['cod']);
    $msg = "Plico Ritirato!";
}
include 'header.php';
?>
<h1>Gestione Operativa Plichi</h1>
<?php if(isset($msg)) echo "<p class='msg-ok'>$msg</p>"; ?>

<h3>1. Accettazione (Nuovo Plico)</h3>
<form method="POST">
    Mittente: <select name="mid"><?php foreach(getClienti($db) as $c) echo "<option value='$c->ID_Cliente'>$c->Nome $c->Cognome</option>"; ?></select>
    Sede Partenza: <select name="sp"><?php foreach(getSedi($db) as $s) echo "<option value='$s->ID_Sede'>$s->Nome</option>"; ?></select>
    Sede Arrivo: <select name="sa"><?php foreach(getSedi($db) as $s) echo "<option value='$s->ID_Sede'>$s->Nome</option>"; ?></select>
    Destinatario (Nome/Cognome/Indirizzo):
    <input type="text" name="nd" placeholder="Nome" required>
    <input type="text" name="cd" placeholder="Cognome" required>
    <input type="text" name="id" placeholder="Indirizzo" required>
    <button type="submit" name="btn_accetta">Registra Consegna</button>
</form>

<h3>2. Spedizione / 3. Ritiro</h3>
<form method="POST">
    Codice Plico: <input type="number" name="cod" required>
    <button type="submit" name="btn_spedisci">Segna come Spedito</button>
    <button type="submit" name="btn_ritira" style="background:green">Conferma Ritiro</button>
</form>