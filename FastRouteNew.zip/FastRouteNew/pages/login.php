<?php
require_once '../configuration/DatabaseConn.php';
$dbconfig = require '../configuration/DBconfiguration.php';
require_once '../function/funzioni_db.php';

$db = DatabaseConn::getDB($dbconfig);

if (isset($_POST['btn_login'])) {
    $u = verificaLogin($db, $_POST['email'], $_POST['password']);
    if ($u) {
        session_start();
        $_SESSION['user_id'] = $u->ID_Personale;
        $_SESSION['tema'] = $u->Tema_Grafico;
        $_SESSION['primo_accesso'] = $u->Primo_Accesso;
        header($u->Primo_Accesso ? "Location: profilo.php" : "Location: dashboard.php");
        exit;
    } else {
        $err = "Credenziali errate.";
    }
}
?>
<?php include 'header.php'; ?>
<h1>Login Personale</h1>
<?php if(isset($err)) echo "<p class='msg-err'>$err</p>"; ?>
<form method="POST">
    Email: <input type="email" name="email" required>
    Password: <input type="password" name="password" required>
    <button type="submit" name="btn_login">Entra</button>
</form>