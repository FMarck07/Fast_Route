<?php
session_start();
$messaggio = isset($_SESSION['messaggio_errore']) ? $_SESSION['messaggio_errore'] : "Errore imprevisto.";
unset($_SESSION['messaggio_errore']);
$pagina_precedente = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'index.php';
?>
<!doctype html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Errore - FastRoute</title>
    <link rel="stylesheet" href="../public/css/style.css">
</head>
<body>
<div class="error-container">
    <h1 class="error-title">Attenzione</h1>
    <h2><?= $messaggio ?></h2><br><br>
    <a href="<?= $pagina_precedente ?>" class="btn">Torna Indietro</a>
    <a href="index.php" class="btn btn-black">Vai alla Home</a>
</div>
</body>
</html>