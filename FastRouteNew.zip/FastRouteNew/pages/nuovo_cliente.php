<?php
require_once '../configuration/DatabaseConn.php';
$dbconfig = require '../configuration/DBconfiguration.php';
require_once '../function/funzioni_db.php';

$db = DatabaseConn::getDB($dbconfig);


if (isset($_POST['btn_cliente'])) {
    try {
        inserisciCliente($db, $_POST['nome'], $_POST['cognome'], $_POST['indirizzo'], $_POST['tel'], $_POST['email']);
        $msg = "<span class='msg-ok'>Cliente registrato con successo!</span>";
    } catch (PDOException $e) {
        session_start();
        $_SESSION['messaggio_errore'] = "Errore registrazione cliente: " . $e->getMessage();
        header("Location: errore.php");
        exit;
    }
}

require_once 'header.php';
?>
    <h1>Registrazione Nuovo Cliente</h1>
<?php if(isset($msg)) echo $msg; ?>
    <form action="nuovo_cliente.php" method="POST">
        Nome: <input type="text" name="nome" required>
        Cognome: <input type="text" name="cognome" required>
        Indirizzo: <input type="text" name="indirizzo" required>
        Telefono: <input type="text" name="tel" required>
        E-mail: <input type="email" name="email" required>
        <button type="submit" name="btn_cliente">Salva Cliente</button>
    </form>
<?php require_once 'footer.php'; ?>