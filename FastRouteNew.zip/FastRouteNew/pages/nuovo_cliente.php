<?php
session_start();

require_once '../configuration/DatabaseConn.php';
$dbconfig = require '../configuration/DBconfiguration.php';
require_once '../function/funzioni_db.php';

$db = DatabaseConn::getDB($dbconfig);

// Controllo accesso
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
if (isset($_SESSION['primo_accesso']) && $_SESSION['primo_accesso']) {
    header("Location: profilo.php");
    exit;
}

$msg = '';

if (isset($_POST['btn_cliente'])) {
    $email = $_POST['email'];
    // Validazione email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $msg = "<span class='msg-err'>Email non valida.</span>";
    } else {
        try {
            inserisciCliente($db, $_POST['nome'], $_POST['cognome'], $_POST['indirizzo'], $_POST['tel'], $email);
            $msg = "<span class='msg-ok'>Cliente registrato con successo!</span>";
        } catch (PDOException $e) {
            $_SESSION['messaggio_errore'] = "Errore registrazione cliente: " . $e->getMessage();
            header("Location: errore.php");
            exit;
        }
    }
}

require_once 'header.php';
?>
    <h1>Registrazione Nuovo Cliente</h1>
<?php if(isset($msg)) echo $msg; ?>
    <form action="nuovo_cliente.php" method="POST">
        Nome: <input type="text" name="nome" required>
        Cognome: <input type="text" name="cognome" required>
        Indirizzo: <input type="text" name="indirizzo" required>
        Telefono: <input type="text" name="tel" required>
        E-mail: <input type="email" name="email" required>
        <button type="submit" name="btn_cliente">Salva Cliente</button>
    </form>
<?php require_once 'footer.php'; ?>