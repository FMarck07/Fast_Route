<?php
session_start();

require_once '../configuration/DatabaseConn.php';
$dbconfig = require '../configuration/DBconfiguration.php';
require_once '../function/funzioni_db.php';
$db = DatabaseConn::getDB($dbconfig);

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if (isset($_POST['btn_pwd'])) {
    $pwd = $_POST['pwd'];
    if (preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/', $pwd)) {
        aggiornaPassword($db, $_SESSION['user_id'], $pwd);
        $_SESSION['primo_accesso'] = false;
        $m = "Password aggiornata!";
    } else { $e = "La password non rispetta i requisiti."; }
}
if (isset($_POST['btn_tema'])) {
    aggiornaTema($db, $_SESSION['user_id'], $_POST['tema']);
    $_SESSION['tema'] = $_POST['tema'];
}
include 'header.php';
?>
    <h1>Profilo di <?= $_SESSION['user_id'] ?></h1>
<?php if($_SESSION['primo_accesso']) echo "<p class='msg-err'>DEVI cambiare password per procedere!</p>"; ?>

    <form method="POST">
        <h3>Cambia Password</h3>
        <?php if(isset($m)) echo "<p class='msg-ok'>$m</p>"; if(isset($e)) echo "<p class='msg-err'>$e</p>"; ?>
        Nuova Password: <input type="password" name="pwd" required>
        <button type="submit" name="btn_pwd">Salva Password</button>
    </form>

    <form method="POST" style="margin-top:20px">
        <h3>Scegli Tema</h3>
        <select name="tema">
            <option value="light">Chiaro</option>
            <option value="dark">Scuro</option>
            <option value="blue">Blu</option>
        </select>
        <button type="submit" name="btn_tema">Cambia Tema</button>
    </form>
<?php include 'footer.php'; ?>