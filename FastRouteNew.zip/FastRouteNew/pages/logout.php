<?php
session_start();

// Svuota tutte le variabili di sessione
$_SESSION = array();

// Distrugge la sessione sul server
session_destroy();

// Reindirizza l'utente alla pagina di login
header("Location: login.php");
exit;
?>