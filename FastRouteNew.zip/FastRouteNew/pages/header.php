<?php
if(session_status() !== PHP_SESSION_ACTIVE) session_start();
$tema = $_SESSION['tema'] ?? 'light';
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>FastRoute</title>
    <link rel="stylesheet" href="../public/css/style.css">
</head>
<body class="tema-<?= $tema ?>">
<div class="navbar">
    <a href="index.php">Home Pubblica</a>
    <?php if(isset($_SESSION['user_id'])): ?>
        <a href="dashboard.php">Dashboard</a>
        <a href="gestione_plichi.php">Operazioni Plichi</a>
        <a href="nuovo_cliente.php">Anagrafica Clienti</a>
        <a href="profilo.php">Mio Profilo</a>
        <a href="logout.php">Esci</a>
    <?php else: ?>
        <a href="login.php">Login Staff</a>
    <?php endif; ?>
</div>