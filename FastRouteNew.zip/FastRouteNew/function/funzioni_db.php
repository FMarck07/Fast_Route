<?php
// LETTURA
function getPlichi($db) {
    return $db->query('SELECT Plico.*, Cliente.Nome, Cliente.Cognome FROM Plico JOIN Cliente ON Plico.ID_Mittente = Cliente.ID_Cliente ORDER BY DataOra_Accettazione DESC');
}
function getClienti($db) { return $db->query('SELECT * FROM Cliente'); }
function getSedi($db) { return $db->query('SELECT * FROM Sede'); }
function verificaLogin($db, $email, $password) {
    $stmt = $db->prepare('SELECT * FROM Personale WHERE Email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    return ($user && password_verify($password, $user->Password)) ? $user : false;
}
function getStatisticheRitiro($db, $giorni) {
    $stmt = $db->prepare("SELECT COUNT(*) as Totale FROM Plico WHERE Stato_Plico = 'Ritirato' AND DataOra_Ritiro >= DATE_SUB(NOW(), INTERVAL ? DAY)");
    $stmt->execute([(int)$giorni]);
    return $stmt->fetch();
}

// SCRITTURA
function inserisciRichiestaInfo($db, $n, $e, $m) {
    $db->prepare('INSERT INTO Richiesta_Info (Nome, Email, Messaggio) VALUES (?,?,?)')->execute([$n,$e,$m]);
}
function inserisciCliente($db, $n, $c, $i, $t, $e) {
    $db->prepare('INSERT INTO Cliente (Nome, Cognome, Indirizzo, Telefono, Email) VALUES (?,?,?,?,?)')->execute([$n,$c,$i,$t,$e]);
}
function inserisciPlico($db, $idm, $nd, $cd, $id, $sp, $sa) {
    $db->prepare('INSERT INTO Plico (ID_Mittente, Nome_Destinatario, Cognome_Destinatario, Indirizzo_Destinatario, ID_Sede_Partenza, ID_Sede_Arrivo) VALUES (?,?,?,?,?,?)')->execute([$idm,$nd,$cd,$id,$sp,$sa]);
}

// AGGIORNAMENTO STATI
function spedisciPlico($db, $id) {
    $db->prepare("UPDATE Plico SET Stato_Plico = 'In Transito', DataOra_Spedizione = NOW() WHERE Codice_Plico = ? AND Stato_Plico = 'In Partenza'")->execute([$id]);
}
function ritiraPlico($db, $id) {
    $db->prepare("UPDATE Plico SET Stato_Plico = 'Ritirato', DataOra_Ritiro = NOW() WHERE Codice_Plico = ?")->execute([$id]);
    $p = $db->prepare("SELECT ID_Mittente FROM Plico WHERE Codice_Plico = ?");
    $p->execute([$id]);
    $res = $p->fetch();
    if($res) $db->prepare("UPDATE Cliente SET Punti_Fedelta = Punti_Fedelta + 1 WHERE ID_Cliente = ?")->execute([$res->ID_Mittente]);
}

// PROFILO
function aggiornaPassword($db, $id, $pwd) {
    $hash = password_hash($pwd, PASSWORD_DEFAULT);
    $db->prepare('UPDATE Personale SET Password = ?, Primo_Accesso = FALSE WHERE ID_Personale = ?')->execute([$hash, $id]);
}
function aggiornaTema($db, $id, $tema) {
    $db->prepare('UPDATE Personale SET Tema_Grafico = ? WHERE ID_Personale = ?')->execute([$tema, $id]);
}
function getRichiesteInfo($db) {
    return $db->query('SELECT * FROM Richiesta_Info ORDER BY Data_Invio DESC');
}

function inoltraMailRichiesta($conn, $nome, $email, $messaggio) {
    try {
        // 1. Salva la richiesta nel database nella tabella Richiesta_Info[cite: 3]
        $sql = "INSERT INTO Richiesta_Info (Nome, Email, Messaggio) VALUES (:nome, :email, :messaggio)";
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            ':nome' => $nome,
            ':email' => $email,
            ':messaggio' => $messaggio
        ]);

        // 2. Inoltra la mail all'amministratore
        $destinatario = "admin@fastroute.it";
        $oggetto = "Nuova richiesta info da: " . $nome;
        $corpo = "Hai ricevuto un nuovo messaggio.\n\nNome: $nome\nEmail: $email\n\nMessaggio:\n$messaggio";
        $headers = "From: noreply@fastroute.it\r\nReply-To: $email\r\n";

        // Esegue l'invio della mail
        mail($destinatario, $oggetto, $corpo, $headers);

        return true;
    } catch (PDOException $e) {
        return false;
    }
}